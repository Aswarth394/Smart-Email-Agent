# ============================================================
# FILE: step2_gmail_auth.py
# PURPOSE: Connect to Gmail using OAuth2 (secure login system)
# 
# WHAT IS OAuth2?
#   OAuth2 = Open Authorization version 2
#   It is a SECURE way to give your program access to Gmail
#   WITHOUT sharing your password with the program.
#   Google gives a "token" (like a temporary key) to your program.
#   This token expires, and can be refreshed automatically.
#
# HOW IT WORKS (flow):
#   1. First run  → Browser opens → You click Allow → token saved
#   2. Next runs  → Token loaded from file → No browser needed
#   3. Token expired? → Auto-refreshed silently
# ============================================================

# --- IMPORTS ---
import os                         # to check if files exist on computer

# Google's official library to handle login tokens (credentials)
from google.oauth2.credentials import Credentials

# Request = used to refresh an expired token
from google.auth.transport.requests import Request

# InstalledAppFlow = creates the browser login popup for desktop apps
from google_auth_oauthlib.flow import InstalledAppFlow

# build = creates a "service object" to talk to Gmail API
from googleapiclient.discovery import build

# HttpError = error type when Gmail API request fails
from googleapiclient.errors import HttpError


# --- SCOPE ---
# SCOPE = what PERMISSION we are asking from Gmail
# 'gmail.readonly' = can only READ emails, cannot delete or send
# This is the SAFEST scope for our agent
SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']


def authenticate_gmail():
    """
    WHAT:  Connect to Gmail and get a service object
    WHY:   We need this service object to call Gmail API later
    HOW:   Check for saved token → use it OR do browser login
    
    RETURNS: Gmail service object (use this to fetch emails)
    """

    creds = None  # creds = credentials (login token), starts as empty

    # STEP 1: Check if we already have a saved token from last time
    # 'token.json' = file where Google saves your login token
    if os.path.exists('token.json'):
        print("  Found saved token. Loading...")
        
        # Load credentials from the saved file
        # SCOPES must match what was used when token was created
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)

    # STEP 2: Check if creds are missing OR expired (not valid anymore)
    if not creds or not creds.valid:

        # Case A: Token exists but expired → refresh it silently
        if creds and creds.expired and creds.refresh_token:
            print("  Token expired. Refreshing automatically...")
            
            # Request() = makes an HTTP call to Google to get a new token
            creds.refresh(Request())

        # Case B: No token at all → open browser for login
        else:
            print("  No token found. Opening browser for Gmail login...")
            print("  >> Please allow access in the browser popup <<")

            # InstalledAppFlow reads 'credentials.json' (from Google Cloud Console)
            # This file has your app's Client ID and Client Secret
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json',  # downloaded from Google Cloud Console
                SCOPES               # what permissions to request
            )

            # run_local_server opens a browser for you to login
            # port=0 means: let Python find any free port automatically
            creds = flow.run_local_server(port=0)

        # STEP 3: Save the token for next time (so browser doesn't open again)
        print("  Saving token for next time...")
        with open('token.json', 'w') as token_file:
            # creds.to_json() converts credentials to a text format
            token_file.write(creds.to_json())

    # STEP 4: Build and return the Gmail service object
    # build('gmail', 'v1', ...) = creates connection to Gmail API version 1
    service = build('gmail', 'v1', credentials=creds)
    print("  Gmail connected successfully!")
    return service


# --- TEST THIS FILE ALONE ---
if __name__ == "__main__":
    print("\n" + "=" * 50)
    print("  TESTING GMAIL AUTHENTICATION")
    print("=" * 50)

    try:
        service = authenticate_gmail()
        
        # Quick test: list Gmail labels (like Inbox, Sent, Spam)
        # This confirms our connection is working
        result = service.users().labels().list(userId='me').execute()
        labels = result.get('labels', [])

        print(f"\n  Connected! Found {len(labels)} Gmail labels:")
        for label in labels[:5]:  # show only first 5 labels
            print(f"    - {label['name']}")

        print("\n  Authentication working perfectly!")

    except HttpError as e:
        # HttpError happens when Gmail API returns an error response
        print(f"  Gmail API error: {e}")
    except FileNotFoundError:
        print("\n  ERROR: credentials.json not found!")
        print("  Go to console.cloud.google.com and download it.")
