# ============================================================
# FILE: step5_week1_complete.py
# PURPOSE: Run the entire Week 1 pipeline from start to finish
#
# PIPELINE OVERVIEW:
#   1. Authenticate with Gmail   (step2)
#   2. Fetch emails              (step3)
#   3. Clean email text          (step4)
#   4. Show a summary report     (this file)
#
# THIS IS YOUR FINAL WEEK 1 DELIVERABLE
# Run this file to see everything working together
# ============================================================

import json
import os
from datetime import datetime

# Import functions from our previous files
from step2_gmail_auth import authenticate_gmail
from step3_fetch_emails import fetch_emails, save_emails_to_json
from step4_clean_emails import clean_all_emails, clean_email_text


# ============================================================
# FUNCTION: Generate Week 1 Summary Report
# ============================================================
def generate_report(emails):
    """
    WHAT:  Print a summary report of all fetched + cleaned emails
    WHY:   To verify our Week 1 pipeline is working correctly
    HOW:   Loop through emails, display key info in a table
    """
    print("\n" + "=" * 70)
    print("  WEEK 1 COMPLETE — EMAIL FETCH & CLEAN REPORT")
    print(f"  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)

    # Count statistics
    total      = len(emails)
    unread     = sum(1 for e in emails if e.get('is_unread'))
    important  = sum(1 for e in emails if e.get('is_important'))
    avg_words  = sum(e.get('word_count', 0) for e in emails) // max(total, 1)

    # Print stats summary
    print(f"\n  Total emails fetched : {total}")
    print(f"  Unread emails        : {unread}")
    print(f"  Important emails     : {important}")
    print(f"  Average word count   : {avg_words} words per email")

    print("\n" + "-" * 70)
    print(f"  {'#':<3} {'SUBJECT':<35} {'FROM':<20} {'WORDS':<6} {'STATUS'}")
    print("-" * 70)

    for i, email in enumerate(emails):
        subject   = email.get('subject', 'No Subject')[:33]
        sender    = email.get('sender', 'Unknown')[:18]
        words     = email.get('word_count', 0)

        # Status indicators
        status_parts = []
        if email.get('is_unread'):    status_parts.append('UNREAD')
        if email.get('is_important'): status_parts.append('IMPORTANT')
        status = ', '.join(status_parts) if status_parts else 'read'

        print(f"  {i+1:<3} {subject:<35} {sender:<20} {words:<6} {status}")

    print("-" * 70)

    # Show one sample email in detail
    if emails:
        print("\n  SAMPLE EMAIL (first one):")
        print("-" * 70)
        sample = emails[0]
        print(f"  Subject : {sample.get('subject', 'N/A')}")
        print(f"  From    : {sample.get('sender', 'N/A')}")
        print(f"  Date    : {sample.get('date', 'N/A')}")
        print(f"\n  Clean Body Preview (first 300 chars):")
        clean_preview = sample.get('body_clean', sample.get('body', ''))[:300]
        print(f"  {clean_preview}...")

    print("\n" + "=" * 70)
    print("  FILES SAVED:")
    print("    emails.json       → raw fetched emails")
    print("    emails_clean.json → cleaned + processed emails")
    print("=" * 70)


# ============================================================
# MAIN: Complete Week 1 Runner
# ============================================================
if __name__ == "__main__":

    print("\n" + "#" * 70)
    print("  SMART EMAIL AGENT — WEEK 1 PIPELINE")
    print("  Student: Aswarth | Project: AIKR")
    print("#" * 70)

    # --------------------------------
    # STAGE 1: AUTHENTICATE
    # --------------------------------
    print("\n[STAGE 1] Authenticating with Gmail...")
    try:
        service = authenticate_gmail()
        print("  Authenticated!")
    except FileNotFoundError:
        print("\n  ERROR: credentials.json not found!")
        print("  Follow these steps:")
        print("  1. Go to https://console.cloud.google.com/")
        print("  2. Create project → Enable Gmail API")
        print("  3. Create OAuth 2.0 Desktop credentials")
        print("  4. Download and rename file to 'credentials.json'")
        print("  5. Put it in this folder and run again")
        exit(1)  # stop the program

    # --------------------------------
    # STAGE 2: FETCH EMAILS
    # --------------------------------
    print("\n[STAGE 2] Fetching emails from Gmail...")

    # Change max_results to fetch more or fewer emails
    emails = fetch_emails(service, max_results=15, label='INBOX')

    if not emails:
        print("  No emails fetched. Check your Gmail inbox.")
        exit(1)

    # Save raw emails to file
    save_emails_to_json(emails, 'emails.json')

    # --------------------------------
    # STAGE 3: CLEAN EMAILS
    # --------------------------------
    print("\n[STAGE 3] Cleaning email text...")
    emails_clean = clean_all_emails('emails.json', 'emails_clean.json')

    # --------------------------------
    # STAGE 4: GENERATE REPORT
    # --------------------------------
    print("\n[STAGE 4] Generating summary report...")
    generate_report(emails_clean)

    print("\n  WEEK 1 PIPELINE COMPLETE!")
    print("  Next step → Week 2: Classify emails with AI")
    print("\n" + "#" * 70)
