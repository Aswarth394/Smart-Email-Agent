# ============================================================
# FILE: step1_setup_check.py
# PURPOSE: Check if all required libraries are installed
# RUN THIS FIRST before anything else
# ============================================================

# 'sys' = built-in Python module to interact with the system
import sys

# List of all libraries we need for Week 1
required = [
    "google.auth",           # handles Google login tokens
    "googleapiclient",       # talks to Google APIs (Gmail, Drive etc.)
    "google_auth_oauthlib",  # handles the OAuth2 login flow (browser popup)
    "bs4",                   # BeautifulSoup - cleans HTML from emails
    "json",                  # saves/reads data in JSON format (built-in)
]

print("=" * 50)
print("  WEEK 1 SETUP CHECK")
print("=" * 50)

all_ok = True

for lib in required:
    try:
        # __import__ tries to import a library
        # If it works → library is installed
        __import__(lib)
        print(f"  [OK]  {lib}")
    except ImportError:
        # If import fails → library is missing
        print(f"  [MISSING] {lib}  ← install this!")
        all_ok = False

print("=" * 50)

if all_ok:
    print("  All libraries installed! Ready to go.")
else:
    print("\n  Run this command to install missing libraries:")
    print("  pip install google-auth google-auth-oauthlib")
    print("  google-api-python-client beautifulsoup4")

print("=" * 50)
