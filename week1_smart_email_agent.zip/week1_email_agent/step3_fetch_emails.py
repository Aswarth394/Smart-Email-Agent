# ============================================================
# FILE: step3_fetch_emails.py
# PURPOSE: Fetch emails from Gmail inbox and extract their content
#
# KEY CONCEPTS:
#   - Gmail stores emails as "messages" with an ID
#   - Each message has "headers" (subject, from, date) and a "body"
#   - Body is encoded in base64 (a way to safely store binary data as text)
#   - We must DECODE the body back to readable text
#   - Emails can be: plain text, HTML, or multipart (both)
# ============================================================

import base64                  # to decode email body from base64 format
import json                    # to save emails as a .json file
import re                      # regex: to clean unwanted characters from text
from bs4 import BeautifulSoup  # to strip HTML tags and get plain text

# Import our authentication function from previous file
from step2_gmail_auth import authenticate_gmail


# ============================================================
# FUNCTION 1: Extract email body text
# ============================================================
def extract_body(payload):
    """
    WHAT:  Get the plain text content from an email's raw data
    WHY:   Email bodies are hidden inside nested "parts" and encoded
    HOW:   Navigate the parts tree → find text/plain → decode base64
    
    PARAMS:
        payload = raw email data structure from Gmail API
    RETURNS:
        body (string) = clean readable text of the email
    """
    body = ""  # start with empty string

    # CASE 1: Email has multiple PARTS (e.g. plain text + HTML version)
    # This is called a "multipart" email
    if 'parts' in payload:

        for part in payload['parts']:
            mime_type = part.get('mimeType', '')

            # We want 'text/plain' → clean readable text
            # We SKIP 'text/html' → has HTML tags like <div>, <p> etc.
            if mime_type == 'text/plain':
                data = part['body'].get('data', '')
                if data:
                    # base64 decode: converts encoded text → readable text
                    # urlsafe_b64decode handles Gmail's URL-safe encoding
                    body = base64.urlsafe_b64decode(data).decode('utf-8')
                    break  # found what we need, stop searching

            # If no plain text, try getting text from HTML (as fallback)
            elif mime_type == 'text/html' and not body:
                data = part['body'].get('data', '')
                if data:
                    html = base64.urlsafe_b64decode(data).decode('utf-8')
                    # BeautifulSoup strips HTML tags → gives us plain text
                    # get_text() extracts only visible text from HTML
                    body = BeautifulSoup(html, 'html.parser').get_text()

            # Handle nested multipart (email inside email)
            elif 'parts' in part:
                # Recursion: call same function on nested part
                nested = extract_body(part)
                if nested:
                    body = nested
                    break

    # CASE 2: Email is simple (no parts, just one body)
    else:
        data = payload.get('body', {}).get('data', '')
        if data:
            body = base64.urlsafe_b64decode(data).decode('utf-8')

    # CLEAN the body: remove extra spaces, newlines, weird characters
    body = re.sub(r'\s+', ' ', body).strip()  # \s+ = one or more whitespace chars

    return body


# ============================================================
# FUNCTION 2: Extract headers (subject, from, date)
# ============================================================
def extract_header(headers, name):
    """
    WHAT:  Find a specific header value by its name
    WHY:   Headers are stored as a list of {'name':..., 'value':...} dicts
    HOW:   Loop through list, find matching name, return its value
    
    PARAMS:
        headers = list of header objects from Gmail
        name    = which header we want (e.g. 'Subject', 'From', 'Date')
    RETURNS:
        value (string) or 'Not found' if header missing
    """
    for header in headers:
        # header['name'] is case-sensitive in Gmail API
        if header['name'].lower() == name.lower():
            return header['value']
    return 'Not found'  # default if header not present


# ============================================================
# FUNCTION 3: Main fetch function
# ============================================================
def fetch_emails(service, max_results=10, label='INBOX'):
    """
    WHAT:  Fetch a list of emails from Gmail
    WHY:   This is the core function of our agent
    HOW:   List message IDs → fetch each full message → extract data
    
    PARAMS:
        service     = Gmail API service object (from authenticate_gmail)
        max_results = how many emails to fetch (default: 10)
        label       = which mailbox to read (INBOX, SPAM, SENT, etc.)
    RETURNS:
        email_list = list of dictionaries, each dict = one email
    """
    print(f"\nFetching {max_results} emails from {label}...")

    # STEP 1: Get list of message IDs
    # Gmail API first gives only IDs, not full content
    # userId='me' means "the authenticated user" (you)
    results = service.users().messages().list(
        userId='me',
        labelIds=[label],      # filter by label (INBOX)
        maxResults=max_results # limit number of results
    ).execute()

    # .get('messages', []) safely returns empty list if no emails
    messages = results.get('messages', [])

    if not messages:
        print("  No emails found.")
        return []

    print(f"  Found {len(messages)} emails. Fetching full content...")

    email_list = []  # will store all processed emails

    for i, msg in enumerate(messages):
        print(f"  Processing email {i+1}/{len(messages)}...", end='\r')

        # STEP 2: Fetch FULL email by its ID
        # format='full' means: give us everything (headers + body)
        email_data = service.users().messages().get(
            userId='me',
            id=msg['id'],    # the message ID from step 1
            format='full'    # 'full' = complete email data
        ).execute()

        # STEP 3: Extract headers from the email
        headers = email_data['payload']['headers']
        subject = extract_header(headers, 'Subject')
        sender  = extract_header(headers, 'From')
        date    = extract_header(headers, 'Date')
        to      = extract_header(headers, 'To')

        # STEP 4: Extract body text
        body = extract_body(email_data['payload'])

        # STEP 5: Get snippet (short preview shown in inbox)
        snippet = email_data.get('snippet', '')

        # STEP 6: Get Gmail labels (INBOX, UNREAD, IMPORTANT, etc.)
        label_ids = email_data.get('labelIds', [])
        is_unread = 'UNREAD' in label_ids     # True if email not yet read
        is_important = 'IMPORTANT' in label_ids  # True if Gmail marked important

        # STEP 7: Build a clean dictionary for this email
        email_dict = {
            'id'          : msg['id'],    # unique Gmail message ID
            'subject'     : subject,
            'sender'      : sender,
            'to'          : to,
            'date'        : date,
            'body'        : body[:2000],  # limit to 2000 chars to save space
            'snippet'     : snippet,
            'is_unread'   : is_unread,
            'is_important': is_important,
            'labels'      : label_ids
        }

        email_list.append(email_dict)

    print(f"\n  Done! Fetched {len(email_list)} emails.")
    return email_list


# ============================================================
# FUNCTION 4: Save emails to JSON file
# ============================================================
def save_emails_to_json(email_list, filename='emails.json'):
    """
    WHAT:  Save list of emails to a JSON file
    WHY:   So we don't need to call Gmail API every time we test
    HOW:   json.dump() converts Python dict → JSON text file
    """
    with open(filename, 'w', encoding='utf-8') as f:
        # indent=2 makes JSON human-readable with 2-space indentation
        json.dump(email_list, f, indent=2, ensure_ascii=False)
    print(f"  Emails saved to '{filename}'")


# ============================================================
# FUNCTION 5: Display emails neatly in terminal
# ============================================================
def display_emails(email_list):
    """
    WHAT:  Print emails to terminal in a clean, readable format
    WHY:   For verification - to see if our fetching is working
    """
    print("\n" + "=" * 60)
    print(f"  FETCHED EMAILS ({len(email_list)} total)")
    print("=" * 60)

    for i, email in enumerate(email_list):
        unread_tag = "[UNREAD]" if email['is_unread'] else "[READ]  "
        print(f"\nEmail #{i+1} {unread_tag}")
        print(f"  From    : {email['sender'][:60]}")
        print(f"  Subject : {email['subject'][:60]}")
        print(f"  Date    : {email['date'][:40]}")
        print(f"  Preview : {email['snippet'][:80]}...")
        print(f"  Body len: {len(email['body'])} characters")


# ============================================================
# MAIN: Run everything
# ============================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  WEEK 1 - EMAIL FETCHER")
    print("=" * 60)

    # Step 1: Authenticate
    service = authenticate_gmail()

    # Step 2: Fetch emails (change max_results to fetch more)
    emails = fetch_emails(service, max_results=10)

    # Step 3: Display them in terminal
    display_emails(emails)

    # Step 4: Save to JSON file for later use
    save_emails_to_json(emails)

    print("\n  Week 1 Complete! emails.json saved.")
    print("  Open emails.json to see your fetched emails.")
