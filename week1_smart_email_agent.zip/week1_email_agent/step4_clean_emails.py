# ============================================================
# FILE: step4_clean_emails.py
# PURPOSE: Clean and preprocess email text for AI processing
#
# WHY CLEAN?
#   Raw email text is messy:
#   - Has HTML tags like <div>, <br>, <a href=...>
#   - Has email headers mixed with body
#   - Has unnecessary whitespace, URLs, email addresses
#   - AI models work BETTER on clean, simple text
#
# WHAT WE DO:
#   Raw messy text → Clean readable text → Ready for AI
# ============================================================

import re    # regex = pattern-based text search and replace
import json  # to load saved emails


# ============================================================
# FUNCTION 1: Remove HTML tags
# ============================================================
def remove_html(text):
    """
    WHAT:  Strip all HTML tags from text
    WHY:   Email bodies often contain HTML like <div>hello</div>
           We want just: "hello"
    HOW:   Regex pattern <.*?> matches any HTML tag
    
    Example:
        Input:  "<p>Hello <b>World</b></p>"
        Output: "Hello World"
    """
    # <.*?> = match < then any characters (.*?) then >
    # ? makes it NON-GREEDY (stops at first > found)
    clean = re.sub(r'<.*?>', ' ', text)
    return clean


# ============================================================
# FUNCTION 2: Remove URLs (web links)
# ============================================================
def remove_urls(text):
    """
    WHAT:  Remove web links from text
    WHY:   URLs like https://click.here.com/abc123 add noise,
           not useful for understanding email meaning
    
    Example:
        Input:  "Click here https://example.com to proceed"
        Output: "Click here  to proceed"
    """
    # https?:// = match http:// or https://
    # \S+       = match any non-space characters after it
    clean = re.sub(r'https?://\S+', '', text)
    return clean


# ============================================================
# FUNCTION 3: Remove email addresses
# ============================================================
def remove_emails_addresses(text):
    """
    WHAT:  Remove email addresses like user@domain.com
    WHY:   Email addresses are not helpful for content analysis
    
    Example:
        Input:  "Contact us at help@company.com for support"
        Output: "Contact us at  for support"
    """
    # \S+@\S+\.\S+ = word@word.word pattern
    clean = re.sub(r'\S+@\S+\.\S+', '', text)
    return clean


# ============================================================
# FUNCTION 4: Remove special characters
# ============================================================
def remove_special_chars(text):
    """
    WHAT:  Keep only letters, numbers, spaces, and basic punctuation
    WHY:   Characters like ©, ™, ►, □ are noise for AI
    
    Example:
        Input:  "Hello © World! Get 50% OFF ►► now!!"
        Output: "Hello  World! Get 50% OFF  now!!"
    """
    # [^\w\s.,!?'-] = keep only: word chars, spaces, and . , ! ? ' -
    # ^ inside [] means NOT these characters
    clean = re.sub(r'[^\w\s.,!?\'-]', ' ', text)
    return clean


# ============================================================
# FUNCTION 5: Fix whitespace
# ============================================================
def fix_whitespace(text):
    """
    WHAT:  Remove duplicate spaces and newlines
    WHY:   After cleaning, text has many gaps/extra spaces
    
    Example:
        Input:  "Hello    world   \n\n  how  are  you"
        Output: "Hello world how are you"
    """
    # \s+ = one or more whitespace (space, tab, newline)
    # Replace all with single space
    clean = re.sub(r'\s+', ' ', text)
    return clean.strip()  # .strip() removes spaces at start and end


# ============================================================
# MAIN CLEANER: Apply all cleaning steps in order
# ============================================================
def clean_email_text(text):
    """
    WHAT:  Apply all cleaning functions in the correct order
    WHY:   Each step prepares for the next one
    HOW:   Pipeline pattern - output of step N = input of step N+1
    
    Pipeline:
        raw text
          → remove HTML           (get rid of tags first)
          → remove URLs           (remove noisy links)
          → remove email addrs    (remove noisy addresses)
          → remove special chars  (keep only useful chars)
          → fix whitespace        (clean up gaps left behind)
          → clean text ✅
    """
    if not text:           # if text is empty or None
        return ""

    text = remove_html(text)
    text = remove_urls(text)
    text = remove_emails_addresses(text)
    text = remove_special_chars(text)
    text = fix_whitespace(text)

    return text


# ============================================================
# FUNCTION 6: Clean all emails from JSON file
# ============================================================
def clean_all_emails(input_file='emails.json', output_file='emails_clean.json'):
    """
    WHAT:  Load raw emails JSON → clean each one → save clean version
    WHY:   Prepare all emails for AI processing in one go
    """
    print("Loading emails from", input_file, "...")

    # Load the JSON file we saved in step3
    with open(input_file, 'r', encoding='utf-8') as f:
        emails = json.load(f)  # json.load() reads JSON file → Python list

    print(f"Cleaning {len(emails)} emails...")

    for i, email in enumerate(emails):
        # Clean the body text
        raw_body     = email.get('body', '')
        raw_snippet  = email.get('snippet', '')
        raw_subject  = email.get('subject', '')

        # Apply cleaning pipeline to each field
        email['body_clean']    = clean_email_text(raw_body)
        email['snippet_clean'] = clean_email_text(raw_snippet)
        email['subject_clean'] = clean_email_text(raw_subject)

        # Word count after cleaning (useful metric)
        email['word_count'] = len(email['body_clean'].split())

        print(f"  Email {i+1}: {len(raw_body)} chars → {len(email['body_clean'])} chars")

    # Save cleaned emails to new file
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(emails, f, indent=2, ensure_ascii=False)

    print(f"\nCleaned emails saved to '{output_file}'")
    return emails


# ============================================================
# MAIN: Test cleaning on sample text
# ============================================================
if __name__ == "__main__":
    print("=" * 60)
    print("  WEEK 1 - EMAIL CLEANER TEST")
    print("=" * 60)

    # Test with a messy sample email body
    sample = """
    <div>Dear Student,<br><br>
    Please visit <a href="https://college.ac.in/portal">https://college.ac.in/portal</a>
    and submit your assignment by Friday!!
    Contact us at admin@college.ac.in if you have issues.
    Best regards,<br>Professor Kumar ©2024</div>
    """

    print("\nRAW TEXT:")
    print(sample[:200])

    cleaned = clean_email_text(sample)

    print("\nCLEANED TEXT:")
    print(cleaned)

    print("\n" + "=" * 60)

    # If emails.json exists, clean all emails
    import os
    if os.path.exists('emails.json'):
        print("\nCleaning all fetched emails...")
        clean_all_emails()
    else:
        print("\nNo emails.json found. Run step3 first.")
        print("Cleaning test passed successfully!")
